#install.packages("xlsx")
#dados_excel <- read.xlsx2(file.choose(), 1)


##--------------- codigo atualizado em 17/05/2022 ----------------

library(xlsx)

#+++++++++++++++++++++++++++++++++++++++++++++++++++++

#Caminho do arquivo xlsx a ser importado
# ARQ_PATH = "A_CAMPO_POLINIZA��O_DOCE_ANO1.xlsx"
# 
# NOVO_ARQ = "CAMPO2.xlsx"

#Numero da guia que ser� importada
# p_sheet = 1

#Ano para ser inserido na origem ou linha anterior
# ano_de_selecao = "2017_2018" 

#Gera��o e safra que ser� avaliada - Ser� criada a nova guia
# nome_nova_guia = "S3-2018-2019"  


#--- Executa importa��o, ajusta origem ou linha anterior e ordena pela parcela atual


AbreLinhas = function(ARQ_PATH,p_sheet,ano_de_selecao,NOVO_ARQ,nome_nova_guia){
require(xlsx)

dados_excel <- read.xlsx(ARQ_PATH, p_sheet)
dados_excel$Plot_bef = paste(dados_excel$Plot_act, "/",ano_de_selecao)
dados_excel$Plot_bef = gsub (" ", "", dados_excel$Plot_bef)
dados_excel$Num_rows[dados_excel$Num_rows==""] <- 0 #Troca celulas blank por 0
dados_excel=dados_excel[order(dados_excel$Plot_act),]
dados_excel


#+++++++++++++++++++++++++++++++++++++++++++++++++++++




#---------------------------IN�CIO -  cria BDs (DFrames) auxiliares ----------------------
dadosaux = data.frame("Plot_act" = numeric(0),
                      "Pedigree" = character(0),
                      "Germop" = character(0),
                      "Plot_bef"=numeric(0),
                      "Selecionado" = character(0),stringsAsFactors=FALSE)

dados.out = data.frame("Plot_act" = numeric(0),
                       "Pedigree" = character(0),
                       "Germop" = character(0),
                       "Plot_bef"=numeric(0),
                       "Selecionado" = character(0),stringsAsFactors=FALSE)

#-------------------------------------

for (i in 1:nrow(dados_excel)){
  
  if (dados_excel[i,5]!=0){
    if (dados_excel[i,5]=="B"){
      dadosaux[1,1]=dados_excel[i,1]
      dadosaux[1,3]=dados_excel[i,3]
      dadosaux[1,4]=dados_excel[i,4]
      dadosaux[1,2]=paste(dados_excel[i,2],"-#",sep="")  #USANDO O SEP NAO FICA ESPA�OS
      dadosaux[1,5]="OK"
      
      dados.out<-rbind(dados.out,dadosaux[1,])
      
    }
      else{
      for (j in 1:dados_excel[i,5]){
        dadosaux[1,1]=dados_excel[i,1]
        dadosaux[1,3]=dados_excel[i,3]
        dadosaux[1,4]=dados_excel[i,4]
        dadosaux[1,2]=paste(dados_excel[i,2],"-",j,sep="")  #USANDO O SEP NAO FICA ESPA�OS
        dadosaux[1,5]="OK"
      
      dados.out<-rbind(dados.out,dadosaux[1,])
      }
    } #fecha o if de bulk (B)
  }
}

dados.out[,5]=NULL
dados.out$Num_rows=""
dados.out$Plot_act=""

write.xlsx(
  dados.out,
  NOVO_ARQ,
  sheetName = nome_nova_guia,
  col.names = T,
  row.names = F,
  password = NULL,
  append=TRUE
)


#---- Realiza o auto ajuste das colunas  ------------------
wb <- loadWorkbook(NOVO_ARQ) 
sheets <- getSheets(wb)
autoSizeColumn(sheets[[1]], colIndex=1:ncol(dados.out))
saveWorkbook(wb,NOVO_ARQ)
##########################################################


} #FECHA A FUN��O AbreLinhas
# ************************** Fechamento de codigo *********************



