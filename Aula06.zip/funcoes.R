stepFunction = function(soma) {
  if (soma >= 1) {
    return (1)
  }
  return (0)
}


#---------------------------------------------------------

calculaSaida = function(registro) {
  soma = registro %*% pesos
  return (stepFunction(soma))
}


#---------------------------------------------------------
