
#------- IN�CIO - FUN��ES PARA GERA��O DE CRUZAMENTOS ------
CreateCross = function(ARQ_PATH_base_cross,
                       Base_Sheet=1,
                       Base_Cross=2,
                       cod_cross,
                       numb_decim=3,
                       name_NEW_File="OUT_cross.xlsx",
                       name_NEW_Sheet="cross"){

  require(xlsx)
  require(stringr)
  
#---- Importa dados base e de cruzamentos

dados_excel = read.xlsx(ARQ_PATH_base_cross, Base_Sheet)
dados_cross = read.xlsx(ARQ_PATH_base_cross, Base_Cross)


#---- Cria data frame auxiliar

db_aux_cross = data.frame("Year" = numeric(0),
                          "Season" = numeric(0),
                          "P1" = numeric(0),
                          "P2" = numeric(0),
                          "Cross" = character(0),
                          "Orig_Plot1" = character(0),
                          "Orig_Plot2" = character(0),
                          "Cod" = character(0),
                          stringsAsFactors=FALSE)


#---- Looping da fun��o

  dados_excel = read.xlsx(ARQ_PATH_base_cross, Base_Sheet)
  dados_cross = read.xlsx(ARQ_PATH_base_cross, Base_Cross)

  nlin_cross = nrow(dados_cross)
  
  for (jj in 1:nlin_cross){
    
    parent1 = dados_cross[jj,1]
    parent2 = dados_cross[jj,2]
    
    pega_dados_p1 = subset(dados_excel, Cod==parent1)
    pega_dados_p2 = subset(dados_excel, Cod==parent2)
    
    db_aux_cross[jj,1] = pega_dados_p1[1,1]
    db_aux_cross[jj,2] = pega_dados_p1[1,2]
    
    db_aux_cross[jj,3] = pega_dados_p1[1,5]
    db_aux_cross[jj,4] = pega_dados_p2[1,5]
    
    db_aux_cross[jj,5] = paste(pega_dados_p1[1,4]," x ",pega_dados_p2[1,4])
    
    db_aux_cross[jj,6] = paste(pega_dados_p1[1,3]," / ",pega_dados_p1[1,1])
    db_aux_cross[jj,7] = paste(pega_dados_p2[1,3]," / ",pega_dados_p2[1,1])
    
    
    db_aux_cross[jj,8] = paste(cod_cross,str_pad(jj, numb_decim, pad = "0"))
    db_aux_cross[jj,8] = gsub(" ", "", db_aux_cross[jj,8], fixed = TRUE)
    
  }
  
  write.xlsx(
    db_aux_cross,
    name_NEW_File,
    sheetName = name_NEW_Sheet,
    col.names = T,
    row.names = F,
    password = NULL,
    append=TRUE,
  )
  
  #---- Realiza o auto ajuste das colunas  ------------------
  wb <- loadWorkbook(name_NEW_File) 
  sheets <- getSheets(wb)
  autoSizeColumn(sheets[[1]], colIndex=1:ncol(db_aux_cross))
  saveWorkbook(wb,name_NEW_File)
  ##########################################################
  
}



#####################################################